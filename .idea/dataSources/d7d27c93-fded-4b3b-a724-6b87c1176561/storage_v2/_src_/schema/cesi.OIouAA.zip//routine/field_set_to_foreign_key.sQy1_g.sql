CREATE PROCEDURE field_set_to_foreign_key()
  BEGIN
	DECLARE done, i, cnt, jid, sid INT;
    DECLARE js, str VARCHAR(255);
    DECLARE curs CURSOR FOR SELECT id, support FROM jeux;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	
    drop table if exists jeux_as_support;
    create table jeux_as_support (
		id_jeux smallint unsigned,
		id_support tinyint unsigned,
		constraint fk_jeux foreign key (id_jeux) references jeux(id),
		constraint fk_support foreign key (id_support) references support(id)
	);
    
    OPEN curs;
    SET done = 0;
    REPEAT
		FETCH curs INTO jid, js;
        SET cnt = ROUND((LENGTH(js) - LENGTH(REPLACE(js, ",", ""))) / LENGTH(",")) + 1;
        SET i = 1;
        WHILE i <= cnt DO
			SET str = lower(trim(both '"' from trim(substring_index(substring_index(js, ',', i), ',', -1))));
            select id into sid from support where nom = str;
            if sid is not null then
				insert into jeux_as_support values (jid, sid);
			end if;
			SET i = i + 1;
		END WHILE;
	UNTIL done END REPEAT;
	CLOSE curs;
END;

